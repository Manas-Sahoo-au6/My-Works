import React from 'react'
import { useState } from 'react'

function Toggler() {
   
   
  

    return (
        <>
        <div className="header">
          <h1>Our Pricing</h1>
          <hr />
        </div>
        <div id="Toggle" className="Toggle">
            <h2>Annualy</h2>
          <input  type="checkbox" id="switch" className="checkbox" />
          <label  for="switch" className="toggle"></label>
          <h2>Monthly</h2>
        </div>
        </>
    )
}

export default Toggler
